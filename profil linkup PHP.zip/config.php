<?php
// ======================================
// LINKUP - CONFIGURATION PHP
// Fichier: config.php
// ======================================

// Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Dossier des données
define('DATA_DIR', __DIR__ . '/data/');

// Créer le dossier data s'il n'existe pas
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0777, true);
}

// ===== FONCTIONS UTILITAIRES =====

/**
 * Lire un fichier JSON
 */
function readJsonFile($filename) {
    $filepath = DATA_DIR . $filename;
    if (file_exists($filepath)) {
        $content = file_get_contents($filepath);
        return json_decode($content, true);
    }
    return null;
}

/**
 * Écrire dans un fichier JSON
 */
function writeJsonFile($filename, $data) {
    $filepath = DATA_DIR . $filename;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return file_put_contents($filepath, $json);
}

/**
 * Vérifier si l'utilisateur est connecté
 */
function isLoggedIn() {
    return isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true;
}

/**
 * Nettoyer les données
 */
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Headers pour JSON
 */
function setJsonHeader() {
    header('Content-Type: application/json; charset=utf-8');
}

/**
 * Envoyer une réponse JSON
 */
function sendJsonResponse($success, $message, $data = null) {
    setJsonHeader();
    $response = [
        'success' => $success,
        'message' => $message
    ];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit;
}
?>