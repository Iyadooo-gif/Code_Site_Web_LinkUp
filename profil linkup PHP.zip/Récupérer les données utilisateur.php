<?php
// ======================================
// LINKUP - RÉCUPÉRER DONNÉES UTILISATEUR
// Fichier: get_user.php
// ======================================

require_once 'config.php';

setJsonHeader();

// Lire les données utilisateur
$user = readJsonFile('user.json');

if ($user) {
    echo json_encode($user);
} else {
    // Retourner des données par défaut
    $defaultUser = [
        'name' => 'Santiago Barnabéu',
        'email' => 'santiago.barnabeu@gmail.com',
        'avatar' => null,
        'created_at' => date('Y-m-d')
    ];
    
    // Créer le fichier avec les données par défaut
    writeJsonFile('user.json', $defaultUser);
    
    echo json_encode($defaultUser);
}
?>