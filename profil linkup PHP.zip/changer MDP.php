<?php
// ======================================
// LINKUP - CHANGER LE MOT DE PASSE
// Fichier: change_password.php
// ======================================

require_once 'config.php';

// Vérifier que c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Méthode non autorisée');
}

// Récupérer les données JSON
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validation
if (!isset($data['current']) || !isset($data['newPassword'])) {
    sendJsonResponse(false, 'Données manquantes');
}

$currentPassword = $data['current'];
$newPassword = $data['newPassword'];

// Validation du nouveau mot de passe
if (strlen($newPassword) < 8) {
    sendJsonResponse(false, 'Le mot de passe doit contenir au moins 8 caractères');
}

// Mot de passe par défaut pour la démo: "password123"
$storedPasswordHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

// Vérifier le mot de passe actuel
if (!password_verify($currentPassword, $storedPasswordHash)) {
    sendJsonResponse(false, 'Mot de passe actuel incorrect');
}

// Hasher le nouveau mot de passe
$newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

// Dans un vrai système, tu sauvegarderais ce hash
$user = readJsonFile('user.json');
if (!$user) {
    $user = [];
}

$user['password_updated_at'] = date('Y-m-d H:i:s');
writeJsonFile('user.json', $user);

sendJsonResponse(true, 'Mot de passe modifié avec succès');
?>