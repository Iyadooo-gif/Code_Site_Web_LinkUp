<?php
// ======================================
// LINKUP - RÉCUPÉRER PRÉFÉRENCES NOTIFICATIONS
// Fichier: get_notifications.php
// ======================================

require_once 'config.php';

setJsonHeader();

// Lire les préférences
$notifications = readJsonFile('notifications.json');

if ($notifications) {
    echo json_encode($notifications);
} else {
    // Retourner des données par défaut
    $defaultNotifications = [
        'email' => true,
        'push' => false
    ];
    
    // Créer le fichier
    writeJsonFile('notifications.json', $defaultNotifications);
    
    echo json_encode($defaultNotifications);
}
?>