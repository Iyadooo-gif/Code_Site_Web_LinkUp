<?php
// ======================================
// LINKUP - SUPPRIMER LE COMPTE
// Fichier: delete_account.php
// ======================================

require_once 'config.php';

// Vérifier que c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Méthode non autorisée');
}

try {
    // Liste des fichiers à supprimer
    $files = ['user.json', 'activities.json', 'notifications.json'];
    
    $deletedFiles = 0;
    
    foreach ($files as $file) {
        $filepath = DATA_DIR . $file;
        if (file_exists($filepath)) {
            if (unlink($filepath)) {
                $deletedFiles++;
            }
        }
    }
    
    // Détruire la session
    if (isset($_SESSION)) {
        session_destroy();
    }
    
    sendJsonResponse(true, 'Compte supprimé avec succès', [
        'files_deleted' => $deletedFiles
    ]);
    
} catch (Exception $e) {
    sendJsonResponse(false, 'Erreur lors de la suppression: ' . $e->getMessage());
}
?>