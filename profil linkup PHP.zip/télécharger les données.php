<?php
// ======================================
// LINKUP - TÉLÉCHARGER LES DONNÉES
// Fichier: download_data.php
// ======================================

require_once 'config.php';

// Charger toutes les données
$user = readJsonFile('user.json');
$activities = readJsonFile('activities.json');
$notifications = readJsonFile('notifications.json');

// Créer l'export complet
$export = [
    'export_date' => date('Y-m-d H:i:s'),
    'export_format' => 'JSON',
    'user_profile' => $user ?: [],
    'activities' => $activities ?: [],
    'notification_preferences' => $notifications ?: []
];

// Convertir en JSON formaté
$json = json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// Headers pour le téléchargement
header('Content-Type: application/json; charset=utf-8');
header('Content-Disposition: attachment; filename="linkup_data_' . date('Y-m-d') . '.json"');
header('Content-Length: ' . strlen($json));
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

echo $json;
exit;
?>