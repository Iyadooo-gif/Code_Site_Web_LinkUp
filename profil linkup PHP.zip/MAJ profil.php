<?php
// ======================================
// LINKUP - METTRE À JOUR LE PROFIL
// Fichier: update_profile.php
// ======================================

require_once 'config.php';

// Vérifier que c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Méthode non autorisée');
}

// Récupérer les données JSON
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validation
if (!isset($data['name']) || !isset($data['email'])) {
    sendJsonResponse(false, 'Données manquantes');
}

$name = sanitize($data['name']);
$email = sanitize($data['email']);

// Validation de l'email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendJsonResponse(false, 'Email invalide');
}

// Validation du nom
if (empty($name) || strlen($name) < 2) {
    sendJsonResponse(false, 'Le nom doit contenir au moins 2 caractères');
}

// Charger les données actuelles
$user = readJsonFile('user.json');

if (!$user) {
    $user = [];
}

// Mettre à jour les données
$user['name'] = $name;
$user['email'] = $email;
$user['updated_at'] = date('Y-m-d H:i:s');

// Sauvegarder
if (writeJsonFile('user.json', $user)) {
    sendJsonResponse(true, 'Profil mis à jour avec succès', $user);
} else {
    sendJsonResponse(false, 'Erreur lors de la sauvegarde');
}
?>