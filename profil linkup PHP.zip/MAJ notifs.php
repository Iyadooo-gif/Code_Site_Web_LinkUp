<?php
// ======================================
// LINKUP - METTRE À JOUR LES NOTIFICATIONS
// Fichier: update_notifications.php
// ======================================

require_once 'config.php';

// Vérifier que c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Méthode non autorisée');
}

// Récupérer les données JSON
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validation
if (!isset($data['type']) || !isset($data['enabled'])) {
    sendJsonResponse(false, 'Données manquantes');
}

$type = $data['type'];
$enabled = (bool) $data['enabled'];

// Vérifier que le type est valide
if (!in_array($type, ['email', 'push'])) {
    sendJsonResponse(false, 'Type de notification invalide');
}

// Charger les préférences actuelles
$notifications = readJsonFile('notifications.json');

if (!$notifications) {
    $notifications = [
        'email' => true,
        'push' => false
    ];
}

// Mettre à jour
$notifications[$type] = $enabled;
$notifications['updated_at'] = date('Y-m-d H:i:s');

// Sauvegarder
if (writeJsonFile('notifications.json', $notifications)) {
    sendJsonResponse(true, 'Préférences mises à jour', $notifications);
} else {
    sendJsonResponse(false, 'Erreur lors de la sauvegarde');
}
?>