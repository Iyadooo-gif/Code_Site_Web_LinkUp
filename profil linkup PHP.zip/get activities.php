<?php
// ======================================
// LINKUP - RÉCUPÉRER LES ACTIVITÉS
// Fichier: get_activities.php
// ======================================

require_once 'config.php';

setJsonHeader();

// Lire les activités
$activities = readJsonFile('activities.json');

if ($activities) {
    echo json_encode($activities);
} else {
    // Retourner des données par défaut
    $defaultActivities = [
        [
            'id' => 1,
            'title' => 'Morning Yoga in the Park',
            'date' => 'June 15, 2024 - 9:00 AM',
            'location' => 'Central Park, New York',
            'status' => 'registered',
            'gradient' => 'linear-gradient(135deg, #84fab0 0%, #8fd3f4 100%)'
        ],
        [
            'id' => 2,
            'title' => 'Beginner Photography',
            'date' => 'June 22, 2024 - 2:00 PM',
            'location' => 'Community Arts Center',
            'status' => 'registered',
            'gradient' => 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
        ],
        [
            'id' => 3,
            'title' => 'Sunset Hike & Picnic',
            'date' => 'July 01, 2024 - 6:00 PM',
            'location' => 'Mountain View Trail',
            'status' => 'registered',
            'gradient' => 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
        ],
        [
            'id' => 4,
            'title' => 'Local Farmers Market Visit',
            'date' => 'July 07, 2024 - 10:00 AM',
            'location' => 'Downtown Plaza',
            'status' => 'registered',
            'gradient' => 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
        ],
        [
            'id' => 5,
            'title' => 'Singing Lessons',
            'date' => 'June 29, 2024 - 7:00 PM',
            'location' => 'Garnier Opera House',
            'status' => 'waiting',
            'gradient' => 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)'
        ],
        [
            'id' => 6,
            'title' => 'Pottery Wheel Workshop',
            'date' => 'July 10, 2024 - 3:00 PM',
            'location' => 'Clay Studio',
            'status' => 'waiting',
            'gradient' => 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)'
        ]
    ];
    
    // Créer le fichier
    writeJsonFile('activities.json', $defaultActivities);
    
    echo json_encode($defaultActivities);
}
?>